# SmartComp AI

A Flask-based salary prediction API.

## Endpoints

### `GET /`
Returns a status message confirming the server is running.

### `POST /predict`
Predicts a salary based on education, experience, and performance scores.

**Request body (JSON):**
```json
{
  "edu": 8,
  "exp": 7,
  "perf": 9
}
```

**Response:**
```json
{
  "salary": 8000.0
}
```

## Running Locally

```bash
pip install -r requirements.txt
python app.py
```

## Deploy on Railway

1. Push this project to a GitHub repository.
2. Go to [railway.app](https://railway.app) and create a new project.
3. Connect your GitHub repository.
4. Railway will auto-detect the configuration and deploy automatically.

The `PORT` environment variable is set automatically by Railway.
