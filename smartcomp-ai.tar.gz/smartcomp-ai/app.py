from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
app.secret_key = "secret"

@app.route("/")
def home():
    return "SmartComp AI Running"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    salary = (data["edu"] * 0.3 + data["exp"] * 0.4 + data["perf"] * 0.3) * 1000
    return jsonify({"salary": salary})

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 3000))
    app.run(host="0.0.0.0", port=port)
